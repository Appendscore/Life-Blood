package com.teamshunya.silencio.Classes;

/**
 * Created by himanshusingh on 24/03/17.
 */

public class Constants {
    public static String PNR_GIVEN = "pnr_given";
    public static String PNR = "pnr";
}
