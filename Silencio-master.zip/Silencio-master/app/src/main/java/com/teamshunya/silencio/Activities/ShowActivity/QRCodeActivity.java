package com.teamshunya.silencio.Activities.ShowActivity;

/**
 * Created by root on 4/2/17.
 */

public class QRCodeActivity {
}
